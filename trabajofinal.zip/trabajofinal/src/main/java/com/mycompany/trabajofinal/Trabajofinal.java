package com.mycompany.trabajofinal;

import java.util.Scanner;

public class Trabajofinal {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int opcion = 0;

        do {
            System.out.println("Bienvenido\n");
            System.out.println("Seleccione la opción que desee: ");
            System.out.println("1. Producto punto de dos vectores");
            System.out.println("2. Producto cruz de dos vectores");
            System.out.println("3. Producto resultante de dos matrices");
            System.out.println("4. Método de Gauss-Jordan");
            System.out.println("5. Matriz transpuesta");
            System.out.println("6. Si desea salir");

            opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    System.out.print("Introduce la dimensión de los vectores para el producto punto: ");
                    int dimension = scanner.nextInt();

                    double[] vector1 = new double[dimension];
                    System.out.println("Introduce los elementos del vector 1:");
                    for (int i = 0; i < dimension; i++) {
                        vector1[i] = scanner.nextDouble();
                    }

                    double[] vector2 = new double[dimension];
                    System.out.println("Introduce los elementos del vector 2:");
                    for (int i = 0; i < dimension; i++) {
                        vector2[i] = scanner.nextDouble();
                    }
                    

                    double productoPunto = 0;
                    for (int i = 0; i < dimension; i++) {
                        productoPunto += vector1[i] * vector2[i];
                    }

                    System.out.println("El producto punto es: " + productoPunto);
                    System.out.println();
                    break;

                case 2:
                    System.out.println("Introduce los elementos del primer vector en R3 para el producto cruz:");
                    double[] vector3 = new double[3];
                    for (int i = 0; i < 3; i++) {
                        vector3[i] = scanner.nextDouble();
                    }

                    System.out.println("Introduce los elementos del segundo vector en R3 para el producto cruz:");
                    double[] vector4 = new double[3];
                    for (int i = 0; i < 3; i++) {
                        vector4[i] = scanner.nextDouble();
                    }
                    

                    double[] resultado = new double[3];
                    resultado[0] = vector3[1] * vector4[2] - vector3[2] * vector4[1];
                    resultado[1] = vector3[2] * vector4[0] - vector3[0] * vector4[2];
                    resultado[2] = vector3[0] * vector4[1] - vector3[1] * vector4[0];

                    System.out.println("El producto cruz es: ");
                    for (int i = 0; i < resultado.length; i++) {
                        System.out.print(resultado[i] + " ");
                    }
                    System.out.println();
                    break;

                case 3:
                    System.out.print("Introduce el número de filas de la matriz 1: ");
                    int filasA = scanner.nextInt();
                    System.out.print("Introduce el número de columnas de la matriz 1: ");
                    int columnasA = scanner.nextInt();
                    System.out.print("Introduce el número de filas de la matriz 2: ");
                    int filasB = scanner.nextInt();
                    System.out.print("Introduce el número de columnas de la matriz 2: ");
                    int columnasB = scanner.nextInt();

                    if (filasA != columnasB) {
                        System.out.println("No se puede resolver, ya que el número de columnas de la matriz 2 no coincide con el número de filas de la matriz 1.");
                        break;
                    }

                    System.out.println("Matriz A:");
                    double[][] A = MatrizA(scanner, filasA, columnasA);

                    System.out.println("Matriz B:");
                    double[][] B = MatrizB(scanner, filasB, columnasB);
                    

                    double[][] multiplicacion = new double[filasA][columnasB];

                     for (int i = 0; i < filasA; i++) {
                        for (int j = 0; j < columnasB; j++) {
                             multiplicacion[i][j] = 0;
                            for (int k = 0; k < columnasA; k++) {
                            multiplicacion[i][j] += A[i][k] * B[k][j];
                        }
                       }
                     }

        
                    System.out.println("La multiplicación de A y B es:");
                    for (int i = 0; i < multiplicacion.length; i++) {
                        for (int j = 0; j < multiplicacion[i].length; j++) {
                             System.out.print(multiplicacion[i][j] + " ");
                        }
                     System.out.println();
                     }
                    System.out.println();
        
                    break;

                case 4:
                    System.out.print("Ingrese el número de filas (ecuaciones): ");
                    int filas = scanner.nextInt();
                    System.out.print("Ingrese el número de columnas (incluyendo términos independientes): ");
                    int columnas = scanner.nextInt();

                    if (filas != columnas - 1) {
                        System.out.println("No se puede resolver, ya que la matriz no es cuadrada.");
                        break;
                    }

                    double[][] matriz = new double[filas][columnas];
                    System.out.println("Ingrese los elementos de la matriz (fila por fila):");
                    for (int i = 0; i < filas; i++) {
                        for (int j = 0; j < columnas; j++) {
                            matriz[i][j] = scanner.nextDouble();
                        }
                    }

                    for (int i = 0; i < filas; i++) {
                        double unos = matriz[i][i];
                        for (int j = 0; j < columnas; j++) {
                            matriz[i][j] /= unos;
                        }

                        for (int k = 0; k < filas; k++) {
                            if (k != i) {
                                double factor = matriz[k][i];
                                for (int j = 0; j < columnas; j++) {
                                    matriz[k][j] = matriz[k][j] - (factor * matriz[i][j]);
                                }
                            }
                        }
                    }

                    System.out.println("Soluciones:");
                    for (int i = 0; i < filas; i++) {
                        System.out.println("Variable " + (i + 1) + ": " + matriz[i][columnas - 1]);
                    }
                    System.out.println();
                    break;

                case 5:
                    System.out.print("Introduce el número de filas de la matriz: ");
                    int filas2 = scanner.nextInt();
                    System.out.print("Introduce el número de columnas de la matriz: ");
                    int columnas2 = scanner.nextInt();

                    double[][] cas = new double[filas2][columnas2];
                    System.out.println("Agrega los elementos de la matriz (fila por fila):");
                    for (int i = 0; i < filas2; i++) {
                        for (int j = 0; j < columnas2; j++) {
                            cas[i][j] = scanner.nextDouble();
                        } 
                    }
                    
                    System.out.println("La matriz es: ");
                    for (int i = 0; i < cas.length; i++) {
                        for (int j = 0; j < cas[i].length; j++) {
                                System.out.print(cas[i][j] + " ");
                        }
                        System.out.println();
                     }
                    
                    System.out.println("La matriz transpuesta es: ");
                    for (int i = 0; i < columnas2; i++) {
                        for (int j = 0; j < filas2; j++) {
                            System.out.print(cas[j][i] + " ");
                        }
                        System.out.println();
                    }
                    System.out.println();
                    break;

                case 6:
                    System.out.println("Salió exitosamente\nVuelva pronto");
                    break;

                default:
                    System.out.println("Opción no válida");
                    break;
            }

        } while (opcion != 6);

        scanner.close();
    }

    public static double[][] MatrizA(Scanner scanner, int filasA, int columnasA) {
        double[][] matriz = new double[filasA][columnasA];
        System.out.println("Introduce los elementos de la matriz A (fila por fila):");
        for (int i = 0; i < filasA; i++) {
            for (int j = 0; j < columnasA; j++) {
                matriz[i][j] = scanner.nextDouble();
            }
        }
        return matriz;
    }

    public static double[][] MatrizB(Scanner scanner, int filasB, int columnasB) {
        double[][] matriz = new double[filasB][columnasB];
        System.out.println("Introduce los elementos de la matriz B (fila por fila):");
        for (int i = 0; i < filasB; i++) {
                
            for (int j = 0; j < columnasB; j++) {
                matriz[i][j] = scanner.nextDouble();
            }
        }
        return matriz;
    }
}